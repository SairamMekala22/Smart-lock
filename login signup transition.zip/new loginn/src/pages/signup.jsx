import React, { useState } from 'react';
import './signup.css'; // Import your CSS here
import {Link} from 'react-router-dom';

function SignupForm() {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div className="App">
      {/* Button container for Owner and Guest Signup */}
      <div className="button-container">
        <button
          className="signup-btn"
          onClick={() => setIsFlipped(false)}
        >
          Owner Signup
        </button>
        <button
          className="signup-btn"
          onClick={() => setIsFlipped(true)}
        >
          Guest Signup
        </button>
      </div>

      {/* Animated Rings */}
      <div className="ring">
        <i style={{ '--clr': '#00ff0a' }}></i>
        <i style={{ '--clr': '#ff0057' }}></i>
        <i style={{ '--clr': '#fffd44' }}></i>

        {/* Signup Form Container */}
        <div className={`signup-container ${isFlipped ? 'flipped' : ''}`}>
          {/* Owner Signup Form */}
          <div className="signup front">
            <h2>Sign-Up</h2>
            <div className="inputBx">
              <input type="text" placeholder="Mobile Number" />
            </div>
            <div className="inputBx">
              <input type="text" placeholder="Full Name" />
            </div>
            <div className="inputBx">
              <input type="text" placeholder="Username" />
            </div>
            <div className="inputBx">
              <input type="password" placeholder="Password" />
            </div>
            <div className="inputBx">
              <input type="submit" value="Sign in" />
            </div>
            <div className="links">
              <a href="#">
                Account already exists?
                <br />
                <Link to="/login" className="linktag">Back to Login</Link>
              </a>
            </div>
          </div>

          {/* Guest Signup Form */}
          <div className="signup back">
            <h2>Guest Sign-Up</h2>
            <div className="inputBx">
              <input type="text" placeholder="Mobile Number" />
            </div>
            <div className="inputBx">
              <input type="text" placeholder="Full Name" />
            </div>
            <div className="inputBx">
              <input type="text" placeholder="Username" />
            </div>
            <div className="inputBx">
              <input type="password" placeholder="Password" />
            </div>
            <div className="inputBx">
              <input type="submit" value="Sign in" />
            </div>
            <div className="links">
              <a href="#">
                Account already exists?
                <br />
                <Link to="/login" className="linktag">Back to Login</Link>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SignupForm;

